﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class cubeController : MonoBehaviour {
	public float amount = 50f;
	public bool rotate = true;
	public bool move = false;
	public float speed = 100000.0F;
	void FixedUpdate()
	{
		if (rotate)
		{
			float h = amount * Time.deltaTime;
			rigidbody.AddTorque(transform.up * h);
			rigidbody.AddTorque(transform.right * h);
		}
		/*if (move)
		{
			
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			RaycastHit hit;
			if (!Physics.Raycast(ray, out hit))
		         return;
			Debug.Log(hit.collider.transform.position.ToString());
			//transform.position = new Vector3(hit.collider.transform.position.x, hit.collider.transform.position.y, -3f);
		}*/
		/*Debug.Log(Input.acceleration.ToString());
		Vector3 dir = Vector3.zero;
        dir.x = -Input.acceleration.y;
        dir.z = Input.acceleration.x;
        if (dir.sqrMagnitude > 1)
            dir.Normalize();
        
        dir *= Time.deltaTime;
        transform.Translate(dir * speed);*/
	}
	void OnCollisionEnter(Collision collision)
	{
		transform.GetComponent<cubeController>().rotate = false;
	}
	public string result = "0";
	private static string[] cubeSides = {"1", "2", "3", "4", "5", "6"};
	void OnCollisionStay(Collision collision)
	{
		//Debug.Log(transform.tag);
		
		//Debug.Log(collision.transform.tag);
		foreach(var contact in collision.contacts)
		{
			string cotStr = contact.thisCollider.tag.ToString();
			if(cubeSides.Contains(cotStr))
			{
				result = cotStr;
				Debug.Log(cotStr);
			}
		}
	}

}
