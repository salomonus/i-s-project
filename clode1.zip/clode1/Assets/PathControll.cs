﻿using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;

public class PathControll : MonoBehaviour {
	private List<PathNode> closedSet;
	private List<PathNode> openSet;
	
	public class PathNode
	{
	  // Коллайдер, что ни на есть адронный :)
	  public Collider NodeCollider { get; set; }
	  // Длина пути от старта (G).
	  public int PathLengthFromStart { get; set; }
	  // Точка, из которой пришли в эту точку.
	  public PathNode CameFrom { get; set; }
	  // Примерное расстояние до цели (H).
	  public float HeuristicEstimatePathLength { get; set; }
	  // Ожидаемое полное расстояние до цели (F).
	  public float EstimateFullPathLength {
	    get {
	      return this.PathLengthFromStart + this.HeuristicEstimatePathLength;
	    }
	  }
	}
	
	void Start()
	{
		closedSet = new List<PathNode>();
		openSet = new List<PathNode>();
		var endObject = GameObject.FindWithTag("end");
		
		Debug.Log("start");
		
		Collider fieldStart = Physics.OverlapSphere(transform.position, 0.5f).FirstOrDefault(x=>x.tag == "field");
		
		Debug.Log(fieldStart.collider.transform.position.ToString());
		
		
		Collider fieldEnd = Physics.OverlapSphere(endObject.transform.position, 0.5f).FirstOrDefault(x=>x.tag == "field");
		
		Debug.Log(fieldEnd.collider.transform.position.ToString());
		
		if (fieldStart == null || fieldEnd == null)
			Debug.Log("no field under start or end lables");
		  PathNode startNode = new PathNode()
		  {
		    NodeCollider = fieldStart,
		    CameFrom = null,
		    PathLengthFromStart = 0,
		    HeuristicEstimatePathLength = GetHeuristicPathLength(fieldStart.transform.position,fieldEnd.transform.position)
		  };
		  openSet.Add(startNode);
	
		while(openSet.Count > 0)
		{
			var currentNode = openSet.OrderBy(node => node.EstimateFullPathLength).First();
			currentNode.NodeCollider.renderer.material.color = Color.red;
			Debug.Log(currentNode.NodeCollider.transform.position.ToString());
			
			if (fieldEnd.collider.transform.position == currentNode.NodeCollider.transform.position)
			{
      			Debug.Log("Finded");
				break;
			}
			openSet.Remove(currentNode);
    		closedSet.Add(currentNode);
			foreach (var neighbourNode in GetNeighbours(currentNode, fieldEnd))
		    {
			  Debug.Log("neightbout: "+ neighbourNode.NodeCollider.transform.position.ToString());
			  Debug.Log("HeuristicEstimatePathLength: "+ neighbourNode.HeuristicEstimatePathLength.ToString());
			  Debug.Log("PathLengthFromStart: "+ neighbourNode.PathLengthFromStart.ToString());
			  Debug.Log("EstimateFullPathLength: "+ neighbourNode.EstimateFullPathLength.ToString());
		      if (closedSet.Where(node => node.NodeCollider.transform.position  == neighbourNode.NodeCollider.transform.position).Count() > 0)
				{
					Debug.Log("continue");
		        	continue;
				}
		      var openNode = openSet.FirstOrDefault(node => node.NodeCollider.transform.position == neighbourNode.NodeCollider.transform.position);

		      if (openNode == null)
			{
				Debug.Log("add");
		        openSet.Add(neighbourNode);
			}
		      else
		        if (openNode.PathLengthFromStart > neighbourNode.PathLengthFromStart)
		        {
				  Debug.Log("not add");
		          openNode.CameFrom = currentNode;
		          openNode.PathLengthFromStart = neighbourNode.PathLengthFromStart;
		        }
		    }
		}
	}
	void Update()
	{

	}
	
	private  IEnumerable<PathNode> GetNeighbours(PathNode pathNode, Collider fieldEnd)
	{
	 
	 
	  foreach (var obj in getGameObjects(pathNode))
	  {
			if (obj != null)
			{
	    // Заполняем данные для точки маршрута.
	    var neighbourNode = new PathNode()
	    {
	      NodeCollider = obj.collider,
	      CameFrom = pathNode,
	      PathLengthFromStart = pathNode.PathLengthFromStart +
	        GetDistanceBetweenNeighbours(),
	      HeuristicEstimatePathLength = GetHeuristicPathLength(obj.transform.position,fieldEnd.transform.position)
	    };
	    yield return neighbourNode;
			}
	  }
			
	  yield break;
	}
	
	private IEnumerable<GameObject> getGameObjects(PathNode pathNode)
	{
		blockController component = pathNode.NodeCollider.GetComponent<blockController>();
		yield return component.leftObject;
		yield return component.rightObject;
		yield return component.topObject;
		yield return component.bottomObject;
		yield break;
	}
	
	private  int GetDistanceBetweenNeighbours()
	{
	  return 1;
	}
	
	private float GetHeuristicPathLength(Vector3 start, Vector3 end)
	{
	  return Math.Abs(start.x - end.x) + Math.Abs(start.y - end.y);
	}
}
