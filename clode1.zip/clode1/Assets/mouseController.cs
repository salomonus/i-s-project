﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class mouseController : MonoBehaviour {
	public LayerMask raycastLayers = 1;
	private RaycastHit hit;
	private Dictionary<int, Vector3> collection = new Dictionary<int, Vector3>(); 
	private int lastKey = 0;
	public float speedAmout = 1.5f;
	//private 
	void Update () {
		Ray scrRay = Camera.main.ScreenPointToRay(Input.mousePosition);
		if (Physics.Raycast(scrRay, out hit, Mathf.Infinity, raycastLayers)) 
        {
			Quaternion normana = Quaternion.FromToRotation(Vector3.up, hit.normal);
			
			if (Input.GetMouseButton(0))
			{
				
				GameObject tcube =  GameObject.FindGameObjectWithTag("tcube");
				tcube.GetComponent<cubeController>().rotate = true;
				tcube.transform.position = new Vector3(hit.point.x-0.5f, hit.point.y, -4);
				
			    GameObject bcube =  GameObject.FindGameObjectWithTag("bcube");
				bcube.GetComponent<cubeController>().rotate = true;
				bcube.transform.position = new Vector3(hit.point.x+0.5f, hit.point.y, -4);
				
				//Debug.Log(Time.deltaTime.ToString());
				//Debug.Log(Time.fixedDeltaTime.ToString());
				//Debug.Log(Time.frameCount.ToString());
				//Debug.Log(Time.maximumDeltaTime.ToString());
				//Debug.Log(Time.realtimeSinceStartup.ToString());
				int key = (int)(Time.renderedFrameCount%100/10);
			    collection[key] = hit.point;
				//Debug.Log(Time.timeScale.ToString());
				lastKey = key;
			}
			if (Input.GetMouseButtonUp(0))
			{
				lock(collection)
				{
					int privKey = lastKey;
					do
					{
						if (privKey > 0)
					 		privKey -= 1;
						else
							privKey = 9;
					}while (!collection.ContainsKey(privKey) && privKey != lastKey);
				
					
					if (privKey != lastKey)
					{
						Vector3 direction = -collection[privKey] + collection[lastKey];
						double _shootSpeed = 0;
						do 
						{			
							if (collection.ContainsKey(privKey))
							{
								Vector3 privVector = -collection[privKey] + collection[lastKey];
								_shootSpeed += Math.Sqrt(Math.Pow(privVector.x, 2) + Math.Pow(privVector.y, 2));
							}
							if (privKey > 0)
						 		privKey -= 1;
							else
								privKey = 9;
						}while (privKey != lastKey);
						
						//Debug.Log(_shootSpeed.ToString());
						
						GameObject tcube =  GameObject.FindGameObjectWithTag("tcube");
						GameObject bcube =  GameObject.FindGameObjectWithTag("bcube");
						//GameObject cube2 =  GameObject.FindGameObjectWithTag("fcube");
						//Ray scrRayc1 = Camera.main.ScreenPointToRay(cube.transform.position);
						//Ray scrRayc2 = Camera.main.ScreenPointToRay(cube2.transform.position);
						
						
						
						if (_shootSpeed > 15)
								_shootSpeed = 15;
						if (_shootSpeed < 4)
								_shootSpeed = 4;
						
						tcube.rigidbody.velocity = speedAmout* (float)_shootSpeed* direction.normalized;
						
						bcube.rigidbody.velocity = speedAmout* (float)_shootSpeed* direction.normalized / 1.2f;
					}
					collection.Clear();
				}
			}
		}
	}
}
