﻿using UnityEngine;
using System.Collections;

public class cube2Controller : MonoBehaviour {
	public float amount = 50f;
	void FixedUpdate()
	{
		//float h = amount * Time.deltaTime;
		//rigidbody.AddTorque(transform.up * -h);
		//rigidbody.AddTorque(transform.right * -h);
		//transform.Rotate(transform.up * -h);
		//transform.Rotate(transform.right * -h);
	}
	void OnCollisionEnter(Collision collision)
	{
		Debug.Log("Enter");
	}
	void OnCollisionStay(Collision collision)
	{
		Debug.Log(transform.tag);
		Debug.Log(collision.transform.tag);
	}
}
