﻿using UnityEngine;
using System.Collections;

public class blockController : MonoBehaviour {
	public GameObject leftObject;
	public GameObject rightObject;
	public GameObject topObject;
	public GameObject bottomObject;
	
}
